"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var shim = require("fabric-shim");
var chaincode_1 = require("./chaincode");
shim.start(new chaincode_1.Chaincode());
//# sourceMappingURL=start.js.map