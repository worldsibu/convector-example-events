import { homedir } from 'os';
import { ClientFactory } from '@worldsibu/convector-core';
import { FabricControllerAdapter } from '@worldsibu/convector-platform-fabric';

import { BankEvents, Transaction } from 'bank-cc';
import { PrescriptionController } from '../src';

(async () => {
  const adapter = new FabricControllerAdapter({
    txTimeout: 300000,
    user: 'user1',
    channel: 'ch1',
    chaincode: 'official',
    keyStore: `/${homedir()}/hyperledger-fabric-network/.hfc-org1`,
    networkProfile: `/${homedir()}/hyperledger-fabric-network/network-profiles/org1.network-profile.yaml`
  });

  await adapter.init();

  const userPeer = adapter.channel.getPeers()
    .find(p => p.getMspid() === adapter.user.getIdentity().getMSPId());
  const hub = adapter.channel.newChannelEventHub(userPeer.getPeer());
  hub.connect(true);

  const storeCtrl = ClientFactory(PrescriptionController, adapter);

  console.log('Listening');
  hub.registerChaincodeEvent(
    'official',
    BankEvents.TxSuccess,
    (event, blockNumber, txId, txStatus) => {
      console.log('Got Event', event.payload.toString('utf8'));
 
      const tx = JSON.parse(event.payload.toString('utf8')) as Transaction;

      storeCtrl.checkPrescription(tx.ref, tx.id);
    },
    (err) => console.error(err),
    {filtered: false} as any
  );
})();